<?php
// Text
$_['text_subject']  = '%s - Product Review';
$_['text_waiting']  = 'You have a new product review waiting.';
$_['text_product']  = 'Product:';
$_['text_reviewer'] = 'Reviewer:';
$_['text_rating']   = 'Rating:';
$_['text_review']   = 'Review Text:';